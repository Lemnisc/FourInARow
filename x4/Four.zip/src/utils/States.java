package utils;

/**
 * Created by Over on 27.01.2015.
 */
public enum States {
    CONNECTED, JOINED, ACCEPTED, LOBBY, READY, CHALLENGED, GAME;
}
